# Listening Forward — physical-look web shell

This folder is ready to replace the contents of `docs/`.

## What works now

- The physical retro-instrument image remains the visual shell.
- The central knob can be dragged with mouse or touch.
- Arrow keys adjust the knob; Shift+arrow gives fine control.
- The live readout shows the blend between adjacent orientations.
- The volume control remains in the lower-left position.
- The left explanation and right monitor space remain part of the reference image.

## What is deliberately not connected yet

- Audio playback
- Active waveform
- Layer monitors
- Scenario visualisation

The JavaScript emits two custom browser events that the future audio engine can use:

- `listeningforward:tune`
- `listeningforward:volume`
