const dial = document.getElementById("dial");
const dialFace = dial.querySelector(".dial-face");
const readout = document.getElementById("orientationReadout");
const volume = document.getElementById("volume");

const orientations = ["Repair", "Automation", "Extraction", "Resilience"];

let angle = 28;
let dragging = false;

function normaliseAngle(value) {
  return ((value % 360) + 360) % 360;
}

function orientationBlend(degrees) {
  const scaled = normaliseAngle(degrees) / 90;
  const leftIndex = Math.floor(scaled) % orientations.length;
  const fraction = scaled - Math.floor(scaled);
  const rightIndex = (leftIndex + 1) % orientations.length;

  return {
    left: orientations[leftIndex],
    right: orientations[rightIndex],
    leftWeight: 1 - fraction,
    rightWeight: fraction
  };
}

function updateDial(nextAngle) {
  angle = normaliseAngle(nextAngle);
  dialFace.style.setProperty("--dial-angle", `${angle}deg`);
  dial.setAttribute("aria-valuenow", String(Math.round(angle)));

  const blend = orientationBlend(angle);
  const leftPercent = Math.round(blend.leftWeight * 100);
  const rightPercent = Math.round(blend.rightWeight * 100);

  readout.textContent =
    rightPercent === 0
      ? `${blend.left} 100%`
      : `${blend.left} ${leftPercent}% · ${blend.right} ${rightPercent}%`;

  // This event is the future connection point for the live audio engine.
  window.dispatchEvent(new CustomEvent("listeningforward:tune", {
    detail: {
      angle,
      orientations: {
        [blend.left.toLowerCase()]: blend.leftWeight,
        [blend.right.toLowerCase()]: blend.rightWeight
      }
    }
  }));
}

function pointerAngle(event) {
  const rect = dial.getBoundingClientRect();
  const centreX = rect.left + rect.width / 2;
  const centreY = rect.top + rect.height / 2;
  const deltaX = event.clientX - centreX;
  const deltaY = event.clientY - centreY;

  return Math.atan2(deltaY, deltaX) * (180 / Math.PI) + 90;
}

dial.addEventListener("pointerdown", event => {
  dragging = true;
  dial.setPointerCapture(event.pointerId);
  updateDial(pointerAngle(event));
});

dial.addEventListener("pointermove", event => {
  if (!dragging) return;
  updateDial(pointerAngle(event));
});

dial.addEventListener("pointerup", event => {
  dragging = false;
  if (dial.hasPointerCapture(event.pointerId)) {
    dial.releasePointerCapture(event.pointerId);
  }
});

dial.addEventListener("pointercancel", () => {
  dragging = false;
});

dial.addEventListener("keydown", event => {
  const fineStep = event.shiftKey ? 1 : 4;

  if (event.key === "ArrowRight" || event.key === "ArrowUp") {
    event.preventDefault();
    updateDial(angle + fineStep);
  }

  if (event.key === "ArrowLeft" || event.key === "ArrowDown") {
    event.preventDefault();
    updateDial(angle - fineStep);
  }

  if (event.key === "Home") {
    event.preventDefault();
    updateDial(0);
  }
});

volume.addEventListener("input", () => {
  window.dispatchEvent(new CustomEvent("listeningforward:volume", {
    detail: { value: Number(volume.value) }
  }));
});

updateDial(angle);
