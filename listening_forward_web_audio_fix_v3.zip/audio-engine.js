(() => {
  "use strict";

  const MANIFEST_URL = "data/sounds.json";
  const ORIENTATIONS = ["repair", "automation", "habitation", "biodiversity"];

  const BED_LAYER_COUNT = 2;
  const RECONCILE_DELAY_MS = 260;
  const GAIN_RESPONSE_SECONDS = 0.9;
  const BED_FADE_SECONDS = 1.8;
  const EVENT_RICH_CROSSFADE_SECONDS = 2.2;
  const REPLACEMENT_MARGIN = 0.025;
  const MIN_KEEP_SCORE = 0.18;
  const EVENT_MIN_SCORE = 0.38;
  const EVENT_GAP_MS = 6500;

  const ROLE_GAINS = {
    base: 0.34,
    texture: 0.24,
    foreground: 0.17,
    accent: 0.12
  };

  const AUTOMATION_CUES = new Set([
    "machine", "machines", "machinery", "signal", "signals",
    "engine", "engines", "tools", "construction", "helicopter",
    "car", "cars", "traffic", "saw", "bell", "bells", "beep",
    "beeps", "foghorn", "boat", "boats"
  ]);

  const HABITATION_CUES = new Set([
    "people", "person", "voices", "voice", "children", "kids",
    "footsteps", "walkers", "walking", "dogs", "dog", "crowd",
    "crawd", "music", "song", "songs", "work", "workers",
    "construction", "boat", "boats", "engine", "engines", "swimming"
  ]);

  const BIODIVERSITY_CUES = new Set([
    "bird", "birds", "birdsong", "monkey", "monkeys", "insects",
    "water", "waves", "wind", "crabs", "vegetation"
  ]);

  const NATURAL_ONLY_TERMS = new Set([
    "water", "waves", "rain", "wind", "bird", "birds", "birdsong"
  ]);

  function clamp(value, minimum, maximum) {
    return Math.min(maximum, Math.max(minimum, value));
  }

  function mulberry32(seed) {
    return function random() {
      let t = seed += 0x6D2B79F5;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  function hasAny(values, vocabulary) {
    return values.some(value => vocabulary.has(String(value).toLowerCase()));
  }

  function isNaturalOnly(elements) {
    return elements.length > 0
      && elements.every(value => NATURAL_ONLY_TERMS.has(String(value).toLowerCase()));
  }

  class ListeningForwardAudioEngine {
    constructor() {
      this.context = null;
      this.masterGain = null;
      this.manifest = null;
      this.soundsById = new Map();
      this.bufferCache = new Map();

      // A "bed" may now be either:
      // - continuous: stable looping ambience;
      // - event_rich base/texture: rotating non-identical excerpts.
      this.activeBeds = new Map();

      this.activeEvents = new Set();
      this.cooldownUntil = new Map();

      this.weights = {
        repair: 1,
        automation: 0,
        habitation: 0,
        biodiversity: 0
      };

      this.volume = 0.72;
      this.started = false;
      this.starting = false;
      this.reconcileTimer = null;
      this.followUpTimer = null;
      this.lastEventAt = 0;

      this.sessionSeed =
        (Date.now() ^ Math.floor(Math.random() * 0xffffffff)) >>> 0;
      this.random = mulberry32(this.sessionSeed);

      this.statusElement = document.getElementById("audioStatus");
      this.manifestPromise = this.loadManifest();

      window.addEventListener("listeningforward:start", () => this.start());
      window.addEventListener("listeningforward:tune", event => {
        this.setWeights(event.detail?.orientations || {});
      });
      window.addEventListener("listeningforward:volume", event => {
        this.setVolume(Number(event.detail?.value ?? this.volume));
      });
    }

    setStatus(message, state = "") {
      if (!this.statusElement) return;
      this.statusElement.textContent = message;
      this.statusElement.dataset.state = state;
    }

    async loadManifest() {
      try {
        const response = await fetch(MANIFEST_URL, { cache: "no-store" });
        if (!response.ok) {
          throw new Error(`Could not load ${MANIFEST_URL} (${response.status})`);
        }

        const manifest = await response.json();
        if (!Array.isArray(manifest.sounds) || manifest.sounds.length === 0) {
          throw new Error(
            "The audio manifest contains no sounds. Rerun export_web_package.py."
          );
        }

        this.manifest = manifest;
        for (const sound of manifest.sounds) {
          this.soundsById.set(sound.id, sound);
        }

        this.setStatus("turn dial to begin", "ready");
        return manifest;
      } catch (error) {
        console.error(error);
        this.setStatus("audio package not exported", "error");
        throw error;
      }
    }

    async start() {
      if (this.started || this.starting) {
        if (this.context?.state === "suspended") {
          await this.context.resume();
        }
        return;
      }

      this.starting = true;

      try {
        await this.manifestPromise;

        const AudioContextClass =
          window.AudioContext || window.webkitAudioContext;

        if (!AudioContextClass) {
          throw new Error("This browser does not support the Web Audio API.");
        }

        this.context = new AudioContextClass();
        this.masterGain = this.context.createGain();
        this.masterGain.gain.value = this.volume;
        this.masterGain.connect(this.context.destination);

        if (this.context.state === "suspended") {
          await this.context.resume();
        }

        this.started = true;
        this.setStatus("listening", "playing");
        await this.reconcile(true);
      } catch (error) {
        console.error(error);
        this.setStatus("audio unavailable", "error");
      } finally {
        this.starting = false;
      }
    }

    setWeights(incoming) {
      const next = Object.fromEntries(
        ORIENTATIONS.map(name => [name, 0])
      );

      for (const name of ORIENTATIONS) {
        next[name] = clamp(Number(incoming[name] || 0), 0, 1);
      }

      const total = Object.values(next)
        .reduce((sum, value) => sum + value, 0);

      if (total > 0) {
        for (const name of ORIENTATIONS) {
          next[name] /= total;
        }
      }

      this.weights = next;

      // Existing beds begin responding immediately.
      if (this.started) {
        this.updateBedGains(GAIN_RESPONSE_SECONDS);
      }

      clearTimeout(this.reconcileTimer);
      this.reconcileTimer = window.setTimeout(() => {
        if (this.started) this.reconcile(false);
      }, RECONCILE_DELAY_MS);
    }

    setVolume(value) {
      this.volume = clamp(value, 0, 1);

      if (!this.masterGain || !this.context) return;

      const now = this.context.currentTime;
      this.masterGain.gain.cancelScheduledValues(now);
      this.masterGain.gain.setTargetAtTime(this.volume, now, 0.06);
    }

    scoreForOrientation(sound, orientation) {
      let score = clamp(
        Number(sound.scores?.[orientation] || 0),
        0,
        1
      );

      const elements = (sound.elements || [])
        .map(value => String(value).toLowerCase());

      const category = String(sound.category || "").toLowerCase();
      const environment = String(sound.environment || "").toLowerCase();
      const humanPresence =
        String(sound.humanPresence || "").toLowerCase();

      if (orientation === "automation") {
        const hasAutomationCue =
          hasAny(elements, AUTOMATION_CUES)
          || category === "machines"
          || category === "urban";

        if (!hasAutomationCue) score *= 0.22;
        if (isNaturalOnly(elements)) score *= 0.25;
      }

      if (orientation === "habitation") {
        const hasHabitationCue =
          hasAny(elements, HABITATION_CUES)
          || humanPresence === "direct"
          || humanPresence === "indirect"
          || category === "urban";

        if (!hasHabitationCue) score *= 0.24;
      }

      if (orientation === "biodiversity") {
        const hasBiodiversityCue =
          hasAny(elements, BIODIVERSITY_CUES)
          || category === "birds"
          || category === "water"
          || environment === "coastal";

        if (!hasBiodiversityCue) score *= 0.28;
      }

      return score;
    }

    orientationScore(sound) {
      return ORIENTATIONS.reduce(
        (sum, name) =>
          sum
          + (this.weights[name] || 0)
          * this.scoreForOrientation(sound, name),
        0
      );
    }

    similarity(sound, anchorId) {
      if (!anchorId || sound.id === anchorId) return 1;

      const item = (sound.neighbours || [])
        .find(neighbour => neighbour.id === anchorId);

      return item
        ? clamp(Number(item.similarity), -1, 1)
        : 0;
    }

    isBedEligible(sound) {
      if (sound.playbackCharacter === "continuous") return true;

      return sound.playbackCharacter === "event_rich"
        && (sound.role === "base" || sound.role === "texture");
    }

    rankedBeds() {
      const activeIds = new Set(this.activeBeds.keys());
      const currentAnchor =
        this.activeBeds.keys().next().value || null;

      return this.manifest.sounds
        .filter(sound => this.isBedEligible(sound))
        .map(sound => {
          let score = this.orientationScore(sound);

          // Similarity preserves continuity, but no longer dominates
          // an unrelated interpretative orientation.
          if (currentAnchor) {
            score +=
              Math.max(0, this.similarity(sound, currentAnchor)) * 0.025;
          }

          if (activeIds.has(sound.id)) score += 0.015;
          if (sound.role === "base" || sound.role === "texture") {
            score += 0.025;
          }

          return { sound, score };
        })
        .sort((left, right) => right.score - left.score);
    }

    desiredGain(sound) {
      const roleGain =
        ROLE_GAINS[sound.role] ?? ROLE_GAINS.texture;

      const relevance = clamp(this.orientationScore(sound), 0, 1);

      // Beds unrelated to the current position disappear fully.
      if (relevance <= 0.12) return 0;

      const normalised = (relevance - 0.12) / 0.88;
      return roleGain * Math.pow(normalised, 1.15);
    }

    updateBedGains(seconds = GAIN_RESPONSE_SECONDS) {
      if (!this.context) return;

      for (const layer of this.activeBeds.values()) {
        this.rampGain(
          layer.gain,
          this.desiredGain(layer.sound),
          seconds
        );
      }
    }

    async reconcile(initial = false) {
      if (!this.started || !this.context || !this.manifest) return;

      const ranked = this.rankedBeds();

      if (ranked.length === 0) {
        this.setStatus("no suitable sound beds available", "error");
        return;
      }

      if (initial || this.activeBeds.size === 0) {
        const initialItems = ranked.slice(0, BED_LAYER_COUNT);
        await Promise.all(
          initialItems.map(item =>
            this.startBed(
              item.sound,
              this.desiredGain(item.sound)
            )
          )
        );
      } else {
        const activeRanked = ranked
          .filter(item => this.activeBeds.has(item.sound.id));

        const inactiveRanked = ranked
          .filter(item => !this.activeBeds.has(item.sound.id));

        const weakestActive = [...activeRanked]
          .sort((left, right) => left.score - right.score)[0];

        const strongestInactive = inactiveRanked[0];

        const shouldReplace =
          weakestActive
          && strongestInactive
          && (
            weakestActive.score < MIN_KEEP_SCORE
            || strongestInactive.score
              > weakestActive.score + REPLACEMENT_MARGIN
          );

        if (shouldReplace) {
          this.fadeOutBed(weakestActive.sound.id);
          await this.startBed(
            strongestInactive.sound,
            this.desiredGain(strongestInactive.sound)
          );

          clearTimeout(this.followUpTimer);
          this.followUpTimer = window.setTimeout(
            () => this.reconcile(false),
            1700
          );
        }
      }

      this.updateBedGains(1.1);
      await this.maybeTriggerEvent();
    }

    async loadBuffer(path) {
      if (this.bufferCache.has(path)) {
        return this.bufferCache.get(path);
      }

      const promise = fetch(path)
        .then(response => {
          if (!response.ok) {
            throw new Error(`Could not load audio file: ${path}`);
          }
          return response.arrayBuffer();
        })
        .then(arrayBuffer =>
          this.context.decodeAudioData(arrayBuffer)
        );

      this.bufferCache.set(path, promise);

      try {
        return await promise;
      } catch (error) {
        this.bufferCache.delete(path);
        throw error;
      }
    }

    chooseFile(sound, excludedPath = null) {
      const files = sound.files || [];
      if (files.length === 0) return null;

      const alternatives = excludedPath && files.length > 1
        ? files.filter(file => file.path !== excludedPath)
        : files;

      const pool = alternatives.length > 0
        ? alternatives
        : files;

      const index = Math.floor(this.random() * pool.length);
      return pool[index];
    }

    async startBed(sound, targetGain) {
      if (this.activeBeds.has(sound.id)) return;

      const gain = this.context.createGain();
      gain.gain.value = 0;
      gain.connect(this.masterGain);

      const layer = {
        sound,
        gain,
        character: sound.playbackCharacter,
        sources: new Set(),
        timer: null,
        stopped: false,
        lastFilePath: null,
        buffers: []
      };

      this.activeBeds.set(sound.id, layer);

      try {
        if (sound.playbackCharacter === "continuous") {
          await this.startContinuousBed(layer);
        } else {
          await this.startEventRichBed(layer);
        }

        this.rampGain(gain, targetGain, BED_FADE_SECONDS);
      } catch (error) {
        console.error(error);
        this.activeBeds.delete(sound.id);
        try { gain.disconnect(); } catch (_) { /* already disconnected */ }
      }
    }

    async startContinuousBed(layer) {
      const file = layer.sound.files?.[0];
      if (!file) return;

      const buffer = await this.loadBuffer(file.path);
      const source = this.context.createBufferSource();

      source.buffer = buffer;
      source.loop = true;
      source.connect(layer.gain);

      const offset = buffer.duration > 2
        ? this.random() * Math.min(buffer.duration - 1, 12)
        : 0;

      source.start(0, offset);
      layer.sources.add(source);

      source.addEventListener("ended", () => {
        layer.sources.delete(source);
        try { source.disconnect(); } catch (_) { /* already disconnected */ }
      });
    }

    async startEventRichBed(layer) {
      const files = layer.sound.files || [];
      if (files.length === 0) return;

      layer.buffers = await Promise.all(
        files.map(async file => ({
          file,
          buffer: await this.loadBuffer(file.path)
        }))
      );

      this.scheduleEventRichSegment(
        layer,
        this.context.currentTime + 0.04
      );
    }

    scheduleEventRichSegment(layer, startAt) {
      if (
        layer.stopped
        || !this.activeBeds.has(layer.sound.id)
        || layer.buffers.length === 0
      ) {
        return;
      }

      const choices = layer.lastFilePath && layer.buffers.length > 1
        ? layer.buffers.filter(
            item => item.file.path !== layer.lastFilePath
          )
        : layer.buffers;

      const item =
        choices[Math.floor(this.random() * choices.length)];

      layer.lastFilePath = item.file.path;

      const source = this.context.createBufferSource();
      const segmentGain = this.context.createGain();
      const buffer = item.buffer;

      source.buffer = buffer;
      segmentGain.gain.value = 0;

      source
        .connect(segmentGain)
        .connect(layer.gain);

      const fade = Math.min(
        EVENT_RICH_CROSSFADE_SECONDS,
        Math.max(0.6, buffer.duration * 0.22)
      );

      const endAt = startAt + buffer.duration;
      const fadeOutAt = Math.max(
        startAt + fade,
        endAt - fade
      );

      segmentGain.gain.setValueAtTime(0, startAt);
      segmentGain.gain.linearRampToValueAtTime(1, startAt + fade);
      segmentGain.gain.setValueAtTime(1, fadeOutAt);
      segmentGain.gain.linearRampToValueAtTime(0, endAt);

      source.start(startAt);
      source.stop(endAt + 0.05);
      layer.sources.add(source);

      source.addEventListener("ended", () => {
        layer.sources.delete(source);
        try { source.disconnect(); } catch (_) { /* already disconnected */ }
        try { segmentGain.disconnect(); } catch (_) { /* already disconnected */ }
      });

      const nextStartAt = endAt - fade;
      const schedulingLead = 0.35;
      const delayMs = Math.max(
        0,
        (nextStartAt - this.context.currentTime - schedulingLead) * 1000
      );

      clearTimeout(layer.timer);
      layer.timer = window.setTimeout(() => {
        this.scheduleEventRichSegment(layer, nextStartAt);
      }, delayMs);
    }

    fadeOutBed(id) {
      const layer = this.activeBeds.get(id);
      if (!layer) return;

      this.activeBeds.delete(id);
      layer.stopped = true;
      clearTimeout(layer.timer);

      this.rampGain(layer.gain, 0, BED_FADE_SECONDS);

      window.setTimeout(() => {
        for (const source of layer.sources) {
          try { source.stop(); } catch (_) { /* already stopped */ }
          try { source.disconnect(); } catch (_) { /* already disconnected */ }
        }

        layer.sources.clear();
        try { layer.gain.disconnect(); } catch (_) { /* already disconnected */ }
      }, (BED_FADE_SECONDS + 0.35) * 1000);
    }

    rampGain(gainNode, target, seconds) {
      const now = this.context.currentTime;
      const parameter = gainNode.gain;

      parameter.cancelScheduledValues(now);
      parameter.setValueAtTime(parameter.value, now);
      parameter.linearRampToValueAtTime(
        Math.max(0, target),
        now + seconds
      );
    }

    async maybeTriggerEvent() {
      const nowMs = Date.now();

      if (
        this.activeEvents.size > 0
        || nowMs - this.lastEventAt < EVENT_GAP_MS
      ) {
        return;
      }

      const activeAnchor =
        this.activeBeds.keys().next().value || null;

      const candidates = this.manifest.sounds
        .filter(sound => {
          if (sound.playbackCharacter === "discrete_event") {
            return true;
          }

          // Event-rich foreground/accent recordings remain occasional events.
          return sound.playbackCharacter === "event_rich"
            && (sound.role === "foreground" || sound.role === "accent");
        })
        .filter(sound => !this.activeBeds.has(sound.id))
        .filter(sound =>
          (this.cooldownUntil.get(sound.id) || 0) <= nowMs
        )
        .map(sound => {
          let score = this.orientationScore(sound);

          if (activeAnchor) {
            score +=
              Math.max(0, this.similarity(sound, activeAnchor)) * 0.08;
          }

          return { sound, score };
        })
        .filter(item => item.score >= EVENT_MIN_SCORE)
        .sort((left, right) => right.score - left.score);

      if (candidates.length === 0) return;

      const top = candidates.slice(
        0,
        Math.min(3, candidates.length)
      );

      const chosen =
        top[Math.floor(this.random() * top.length)];

      await this.playEvent(chosen.sound, chosen.score);
    }

    async playEvent(sound, score) {
      const file = this.chooseFile(sound);
      if (!file) return;

      try {
        const buffer = await this.loadBuffer(file.path);
        const source = this.context.createBufferSource();
        const gain = this.context.createGain();

        source.buffer = buffer;
        gain.gain.value = 0;

        source
          .connect(gain)
          .connect(this.masterGain);

        const roleGain =
          ROLE_GAINS[sound.role] ?? ROLE_GAINS.accent;

        const target =
          roleGain * (0.42 + clamp(score, 0, 1) * 0.58);

        const now = this.context.currentTime;
        const discrete =
          sound.playbackCharacter === "discrete_event";

        const fadeIn = discrete ? 0.65 : 1.4;
        const fadeOut = discrete ? 1.1 : 1.8;

        gain.gain.setValueAtTime(0, now);
        gain.gain.linearRampToValueAtTime(
          target,
          now + fadeIn
        );

        const fadeStart = Math.max(
          now + fadeIn,
          now + buffer.duration - fadeOut
        );

        gain.gain.setValueAtTime(target, fadeStart);
        gain.gain.linearRampToValueAtTime(
          0,
          now + buffer.duration
        );

        const token = `${sound.id}:${now}`;
        this.activeEvents.add(token);
        this.lastEventAt = Date.now();

        const cooldown = discrete ? 36000 : 18000;
        this.cooldownUntil.set(
          sound.id,
          Date.now() + cooldown
        );

        source.addEventListener("ended", () => {
          this.activeEvents.delete(token);
          try { source.disconnect(); } catch (_) { /* already disconnected */ }
          try { gain.disconnect(); } catch (_) { /* already disconnected */ }
        });

        source.start();
      } catch (error) {
        console.error(error);
      }
    }
  }

  window.listeningForwardAudio =
    new ListeningForwardAudioEngine();
})();
