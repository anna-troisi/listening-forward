(() => {
  "use strict";

  const MANIFEST_URL = "data/sounds.json";
  const ORIENTATIONS = ["repair", "automation", "habitation", "biodiversity"];
  const CONTINUOUS_LAYER_COUNT = 2;
  const RECONCILE_DELAY_MS = 420;
  const LAYER_FADE_SECONDS = 2.6;
  const REPLACEMENT_MARGIN = 0.04;
  const EVENT_MIN_SCORE = 0.36;

  const ROLE_GAINS = {
    base: 0.34,
    texture: 0.24,
    foreground: 0.17,
    accent: 0.12
  };

  function clamp(value, minimum, maximum) {
    return Math.min(maximum, Math.max(minimum, value));
  }

  function hashString(text) {
    let hash = 2166136261;
    for (let i = 0; i < text.length; i += 1) {
      hash ^= text.charCodeAt(i);
      hash = Math.imul(hash, 16777619);
    }
    return hash >>> 0;
  }

  function mulberry32(seed) {
    return function random() {
      let t = seed += 0x6D2B79F5;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  class ListeningForwardAudioEngine {
    constructor() {
      this.context = null;
      this.masterGain = null;
      this.manifest = null;
      this.soundsById = new Map();
      this.bufferCache = new Map();
      this.activeContinuous = new Map();
      this.activeEvents = new Set();
      this.cooldownUntil = new Map();
      this.weights = {
        repair: 1,
        automation: 0,
        habitation: 0,
        biodiversity: 0
      };
      this.volume = 0.72;
      this.started = false;
      this.starting = false;
      this.reconcileTimer = null;
      this.followUpTimer = null;
      this.lastEventAt = 0;
      this.sessionSeed = (Date.now() ^ Math.floor(Math.random() * 0xffffffff)) >>> 0;
      this.random = mulberry32(this.sessionSeed);
      this.statusElement = document.getElementById("audioStatus");
      this.manifestPromise = this.loadManifest();

      window.addEventListener("listeningforward:start", () => this.start());
      window.addEventListener("listeningforward:tune", event => {
        this.setWeights(event.detail?.orientations || {});
      });
      window.addEventListener("listeningforward:volume", event => {
        this.setVolume(Number(event.detail?.value ?? this.volume));
      });
    }

    setStatus(message, state = "") {
      if (!this.statusElement) return;
      this.statusElement.textContent = message;
      this.statusElement.dataset.state = state;
    }

    async loadManifest() {
      try {
        const response = await fetch(MANIFEST_URL, { cache: "no-store" });
        if (!response.ok) {
          throw new Error(`Could not load ${MANIFEST_URL} (${response.status})`);
        }
        const manifest = await response.json();
        if (!Array.isArray(manifest.sounds) || manifest.sounds.length === 0) {
          throw new Error("The audio manifest contains no sounds.");
        }
        this.manifest = manifest;
        for (const sound of manifest.sounds) {
          this.soundsById.set(sound.id, sound);
        }
        this.setStatus("turn dial to begin", "ready");
        return manifest;
      } catch (error) {
        console.error(error);
        this.setStatus("audio package not exported", "error");
        throw error;
      }
    }

    async start() {
      if (this.started || this.starting) {
        if (this.context?.state === "suspended") {
          await this.context.resume();
        }
        return;
      }

      this.starting = true;
      try {
        await this.manifestPromise;
        const AudioContextClass = window.AudioContext || window.webkitAudioContext;
        if (!AudioContextClass) {
          throw new Error("This browser does not support the Web Audio API.");
        }

        this.context = new AudioContextClass();
        this.masterGain = this.context.createGain();
        this.masterGain.gain.value = this.volume;
        this.masterGain.connect(this.context.destination);

        if (this.context.state === "suspended") {
          await this.context.resume();
        }

        this.started = true;
        this.setStatus("listening", "playing");
        await this.reconcile(true);
      } catch (error) {
        console.error(error);
        this.setStatus("audio unavailable", "error");
      } finally {
        this.starting = false;
      }
    }

    setWeights(incoming) {
      const next = Object.fromEntries(ORIENTATIONS.map(name => [name, 0]));
      for (const name of ORIENTATIONS) {
        next[name] = clamp(Number(incoming[name] || 0), 0, 1);
      }
      const total = Object.values(next).reduce((sum, value) => sum + value, 0);
      if (total > 0) {
        for (const name of ORIENTATIONS) next[name] /= total;
      }
      this.weights = next;

      // Existing layers respond immediately to the dial. Full layer
      // replacement remains lightly debounced to avoid nervous switching.
      if (this.started) {
        this.updateContinuousGains(1.6);
      }

      clearTimeout(this.reconcileTimer);
      this.reconcileTimer = setTimeout(() => {
        if (this.started) this.reconcile(false);
      }, RECONCILE_DELAY_MS);
    }

    setVolume(value) {
      this.volume = clamp(value, 0, 1);
      if (!this.masterGain || !this.context) return;
      const now = this.context.currentTime;
      this.masterGain.gain.cancelScheduledValues(now);
      this.masterGain.gain.setTargetAtTime(this.volume, now, 0.08);
    }

    orientationScore(sound) {
      return ORIENTATIONS.reduce(
        (sum, name) => sum + (this.weights[name] || 0) * (sound.scores?.[name] || 0),
        0
      );
    }

    similarity(sound, anchorId) {
      if (!anchorId || sound.id === anchorId) return 1;
      const item = (sound.neighbours || []).find(neighbour => neighbour.id === anchorId);
      return item ? clamp(Number(item.similarity), -1, 1) : 0;
    }

    rankedContinuous() {
      const activeIds = new Set(this.activeContinuous.keys());
      const currentAnchor = this.activeContinuous.keys().next().value || null;

      return this.manifest.sounds
        .filter(sound => sound.playbackCharacter === "continuous")
        .map(sound => {
          let score = this.orientationScore(sound);
          if (currentAnchor) score += Math.max(0, this.similarity(sound, currentAnchor)) * 0.07;
          if (activeIds.has(sound.id)) score += 0.035;
          if (sound.role === "texture" || sound.role === "base") score += 0.04;
          return { sound, score };
        })
        .sort((a, b) => b.score - a.score);
    }

    desiredGain(sound) {
      const roleGain = ROLE_GAINS[sound.role] ?? ROLE_GAINS.texture;
      const relevance = clamp(this.orientationScore(sound), 0, 1);

      // A sound that is weakly related to the current dial position should
      // be allowed to disappear. The earlier 38% floor made opening water
      // or wind layers remain audible across unrelated orientations.
      if (relevance <= 0.08) return 0;

      const normalised = (relevance - 0.08) / 0.92;
      return roleGain * Math.pow(normalised, 1.25);
    }

    updateContinuousGains(seconds = 1.6) {
      if (!this.context) return;
      for (const layer of this.activeContinuous.values()) {
        this.rampGain(layer.gain, this.desiredGain(layer.sound), seconds);
      }
    }

    async reconcile(initial = false) {
      if (!this.started || !this.context || !this.manifest) return;

      const ranked = this.rankedContinuous();
      if (ranked.length === 0) {
        this.setStatus("no continuous recordings available", "error");
        return;
      }

      if (initial || this.activeContinuous.size === 0) {
        const initialItems = ranked.slice(0, CONTINUOUS_LAYER_COUNT);
        const maximum = initialItems[0]?.score || 1;
        for (const item of initialItems) {
          await this.startContinuous(item.sound, this.desiredGain(item.sound));
        }
      } else {
        const activeRanked = ranked.filter(item => this.activeContinuous.has(item.sound.id));
        const inactiveRanked = ranked.filter(item => !this.activeContinuous.has(item.sound.id));
        const weakestActive = [...activeRanked].sort((a, b) => a.score - b.score)[0];
        const strongestInactive = inactiveRanked[0];

        if (
          weakestActive && strongestInactive &&
          strongestInactive.score > weakestActive.score + REPLACEMENT_MARGIN
        ) {
          await this.fadeOutContinuous(weakestActive.sound.id);
          await this.startContinuous(
            strongestInactive.sound,
            this.desiredGain(strongestInactive.sound)
          );

          clearTimeout(this.followUpTimer);
          this.followUpTimer = setTimeout(() => this.reconcile(false), 2400);
        }
      }

      this.updateContinuousGains(2.0);

      await this.maybeTriggerEvent();
    }

    async loadBuffer(path) {
      if (this.bufferCache.has(path)) return this.bufferCache.get(path);

      const promise = fetch(path)
        .then(response => {
          if (!response.ok) throw new Error(`Could not load audio file: ${path}`);
          return response.arrayBuffer();
        })
        .then(arrayBuffer => this.context.decodeAudioData(arrayBuffer));

      this.bufferCache.set(path, promise);
      try {
        return await promise;
      } catch (error) {
        this.bufferCache.delete(path);
        throw error;
      }
    }

    chooseFile(sound) {
      const files = sound.files || [];
      if (files.length === 0) return null;
      const index = Math.floor(this.random() * files.length);
      return files[index];
    }

    async startContinuous(sound, targetGain) {
      const file = sound.files?.[0];
      if (!file) return;

      try {
        const buffer = await this.loadBuffer(file.path);
        const source = this.context.createBufferSource();
        const gain = this.context.createGain();
        source.buffer = buffer;
        source.loop = true;
        gain.gain.value = 0;
        source.connect(gain).connect(this.masterGain);

        const offset = buffer.duration > 2 ? this.random() * Math.min(buffer.duration - 1, 12) : 0;
        source.start(0, offset);

        this.activeContinuous.set(sound.id, { sound, source, gain });
        this.rampGain(gain, targetGain, LAYER_FADE_SECONDS);
      } catch (error) {
        console.error(error);
      }
    }

    async fadeOutContinuous(id) {
      const layer = this.activeContinuous.get(id);
      if (!layer) return;
      this.activeContinuous.delete(id);
      this.rampGain(layer.gain, 0, LAYER_FADE_SECONDS);
      window.setTimeout(() => {
        try { layer.source.stop(); } catch (_) { /* already stopped */ }
        try { layer.source.disconnect(); } catch (_) { /* already disconnected */ }
        try { layer.gain.disconnect(); } catch (_) { /* already disconnected */ }
      }, (LAYER_FADE_SECONDS + 0.4) * 1000);
    }

    rampGain(gainNode, target, seconds) {
      const now = this.context.currentTime;
      const parameter = gainNode.gain;
      parameter.cancelScheduledValues(now);
      parameter.setValueAtTime(parameter.value, now);
      parameter.linearRampToValueAtTime(Math.max(0, target), now + seconds);
    }

    async maybeTriggerEvent() {
      const nowMs = Date.now();
      if (this.activeEvents.size > 0 || nowMs - this.lastEventAt < 8500) return;

      const activeAnchor = this.activeContinuous.keys().next().value || null;
      const candidates = this.manifest.sounds
        .filter(sound => sound.playbackCharacter !== "continuous")
        .filter(sound => (this.cooldownUntil.get(sound.id) || 0) <= nowMs)
        .map(sound => {
          let score = this.orientationScore(sound);
          if (activeAnchor) score += Math.max(0, this.similarity(sound, activeAnchor)) * 0.12;
          return { sound, score };
        })
        .filter(item => item.score >= EVENT_MIN_SCORE)
        .sort((a, b) => b.score - a.score);

      if (candidates.length === 0) return;
      const top = candidates.slice(0, Math.min(3, candidates.length));
      const chosen = top[Math.floor(this.random() * top.length)];
      await this.playEvent(chosen.sound, chosen.score);
    }

    async playEvent(sound, score) {
      const file = this.chooseFile(sound);
      if (!file) return;

      try {
        const buffer = await this.loadBuffer(file.path);
        const source = this.context.createBufferSource();
        const gain = this.context.createGain();
        source.buffer = buffer;
        gain.gain.value = 0;
        source.connect(gain).connect(this.masterGain);

        const roleGain = ROLE_GAINS[sound.role] ?? ROLE_GAINS.accent;
        const target = roleGain * (0.45 + clamp(score, 0, 1) * 0.55);
        const now = this.context.currentTime;
        const fadeIn = sound.playbackCharacter === "discrete_event" ? 0.7 : 1.8;
        const fadeOut = sound.playbackCharacter === "discrete_event" ? 1.2 : 2.2;

        gain.gain.setValueAtTime(0, now);
        gain.gain.linearRampToValueAtTime(target, now + fadeIn);
        const fadeStart = Math.max(now + fadeIn, now + buffer.duration - fadeOut);
        gain.gain.setValueAtTime(target, fadeStart);
        gain.gain.linearRampToValueAtTime(0, now + buffer.duration);

        const eventToken = `${sound.id}:${now}`;
        this.activeEvents.add(eventToken);
        this.lastEventAt = Date.now();
        const cooldown = sound.playbackCharacter === "discrete_event" ? 36000 : 20000;
        this.cooldownUntil.set(sound.id, Date.now() + cooldown);

        source.addEventListener("ended", () => {
          this.activeEvents.delete(eventToken);
          try { source.disconnect(); } catch (_) { /* already disconnected */ }
          try { gain.disconnect(); } catch (_) { /* already disconnected */ }
        });
        source.start();
      } catch (error) {
        console.error(error);
      }
    }
  }

  window.listeningForwardAudio = new ListeningForwardAudioEngine();
})();
